hnews_visual
============
Peregrine Badger
Brian Connolly

Project 2 for CS 171 

