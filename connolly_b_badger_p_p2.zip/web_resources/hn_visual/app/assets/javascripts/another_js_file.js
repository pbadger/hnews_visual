$(function(){
  console.log('def');
});