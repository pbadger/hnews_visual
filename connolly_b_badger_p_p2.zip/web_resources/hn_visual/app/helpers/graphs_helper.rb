module GraphsHelper
end
