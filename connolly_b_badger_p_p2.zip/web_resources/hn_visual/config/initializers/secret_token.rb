# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
HnVisual::Application.config.secret_token = '88b44f22d9d1f418ff18017515f17ba8730a369529ed1675ade845ebe30db8fa8ae2987770f9732fb5038d78558654f47bfc64f6b1cfe0f987566d2a0a2ff5ef'
