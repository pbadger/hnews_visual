require 'test_helper'

class GraphsHelperTest < ActionView::TestCase
end
