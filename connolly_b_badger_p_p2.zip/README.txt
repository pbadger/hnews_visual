README

Right now, we can't get the two halves of our project to work on one page. Index.html contains the main visualization.